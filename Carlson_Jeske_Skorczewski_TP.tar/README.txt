This package contains the CS455 Introduction to Distributed Systems Term Project for Caleb Carlson, Aislinn, Jeske, and Cassidy Skorczewski

This package contains the following files:

src.main.scala

| -- dayPrices [This class calculates the amount of money you will spend each day on food and transportation in each city at the specified budget level]
| -- readAirbnbData [This class calculates the nightly airbnb rental costs in each city at the specified budget level]
| -- readAirbnbDataDeposits [This class calculates the fees associated with the airbnb’s in each city at the specified budget level]
| -- calculateNumNights [This class combines the output from previous programs to calculate how long you can stay in each city at the specified budget level]

